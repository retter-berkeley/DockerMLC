from .dynamics import VanDerPol
from .dynamics import Lorenz
from .dynamics import MeanField
from .dynamics import MGM